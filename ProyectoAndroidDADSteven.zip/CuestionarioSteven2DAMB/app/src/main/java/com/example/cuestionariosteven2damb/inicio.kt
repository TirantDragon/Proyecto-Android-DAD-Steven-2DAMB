package com.example.cuestionariosteven2damb

import android.content.Intent
import android.os.Bundle
import android.speech.RecognizerIntent
import android.widget.Button
import android.widget.ImageButton
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.util.Locale

class inicio : AppCompatActivity() {

    // Código de solicitud para el reconocimiento de voz
    private val SPEECH_REQUEST_CODE = 1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_inicio)

        // Configura los botones normales
        findViewById<Button>(R.id.btn_cuest).setOnClickListener {
            val intent = Intent(this, cuestionarios::class.java)
            startActivity(intent)
        }

        findViewById<Button>(R.id.btn_perfil).setOnClickListener {
            val intent = Intent(this, perfil::class.java)
            startActivity(intent)
        }

        findViewById<Button>(R.id.btn_ranking).setOnClickListener {
            Toast.makeText(this, "Sección en desarrollo...", Toast.LENGTH_SHORT).show()
        }

        // Configura el botón de reconocimiento por voz
        val voiceButton = findViewById<ImageButton>(R.id.btn_voz)
        voiceButton.setOnClickListener {
            startSpeechToText()
        }
    }

    /**
     * Método para iniciar el reconocimiento de voz
     */
    private fun startSpeechToText() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Habla ahora para ejecutar un comando")
        }
        try {
            startActivityForResult(intent, SPEECH_REQUEST_CODE)
        } catch (e: Exception) {
            Toast.makeText(this, "El reconocimiento de voz no está disponible", Toast.LENGTH_SHORT).show()
        }
    }

    /**
     * Método para manejar los resultados del reconocimiento de voz
     */
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == SPEECH_REQUEST_CODE && resultCode == RESULT_OK) {
            val result = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            val voiceCommand = result?.get(0)?.lowercase(Locale.getDefault())

            // Procesar los comandos reconocidos
            when {
                voiceCommand?.contains("cuestionarios") == true -> {
                    Toast.makeText(this, "Abriendo Cuestionarios...", Toast.LENGTH_SHORT).show()
                    startActivity(Intent(this, cuestionarios::class.java))
                }
                voiceCommand?.contains("perfil") == true -> {
                    Toast.makeText(this, "Abriendo Perfil...", Toast.LENGTH_SHORT).show()
                    startActivity(Intent(this, perfil::class.java))
                }
                voiceCommand?.contains("cerrar sesión") == true -> {
                    Toast.makeText(this, "Cerrando sesión...", Toast.LENGTH_SHORT).show()
                    startActivity(Intent(this, Login::class.java))
                }
                else -> {
                    Toast.makeText(this, "Comando no reconocido: $voiceCommand", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
}
