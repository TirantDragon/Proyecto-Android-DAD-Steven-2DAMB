package com.example.cuestionariosteven2damb

import android.content.Context
import android.database.sqlite.SQLiteOpenHelper
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteDatabase.CursorFactory

class AdminSQLiteOpenHelper(context: Context, name: String, factory: CursorFactory?,
                            version: Int) : SQLiteOpenHelper(context, name, factory, version) {

    override fun onCreate(db: SQLiteDatabase) {
        // Creación de la tabla 'sesion'
        db.execSQL("create table sesion(codigo int primary key, user text, password text, puntuacion int)")

        // Creación de la tabla 'preguntas'
        db.execSQL("create table preguntas(id int primary key, pregunta text, opcion1 text, opcion2 text, opcion3 text, opcion4 text, correcta text, dificultad text, id_cuestionario int)")

        // Creación de la tabla 'cuestionario'
        db.execSQL("create table cuestionario(id_cuestionario int primary key, nombre text)")

        // Creación de la tabla 'ranking'
        db.execSQL("create table ranking(id_ranking int primary key, id_user int, id_cuestionario int, puntuacion int, fecha date)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
    }
}
